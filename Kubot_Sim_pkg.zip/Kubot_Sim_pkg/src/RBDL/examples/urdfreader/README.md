# URDF Files

To test this example a URDF file is needed. The repositories below contain good examples. Be sure to download the 'raw' file if you are obtaining it from github. 

1. Poppy Project: https://raw.githubusercontent.com/poppy-project/poppy-humanoid/master/hardware/URDF/robots/Poppy_Humanoid.URDF

2. ROS Examples:  http://wiki.ros.org/urdf/Examples


