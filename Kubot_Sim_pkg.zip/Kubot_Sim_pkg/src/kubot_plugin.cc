/*
 * RoK-3 Gazebo Simulation Code 
 * 
 * Robotics & Control Lab.
 * 
 * Master : BKCho
 * First developer : Yunho Han
 * Second developer : Minho Park
 * 
 * ======
 * Update date : 2022.03.16 by Yunho Han
 * ======
 */
//* Header file for C++
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <boost/bind.hpp>

#include <time.h>

#define X_ 0
#define Y_ 1
#define Z_ 2

//* Header file for Gazebo and Ros
#include <gazebo/gazebo.hh>
#include <ros/ros.h>
#include <gazebo/common/common.hh>
#include <gazebo/physics/physics.hh>
#include <gazebo/sensors/sensors.hh>
#include <std_msgs/Float32MultiArray.h>
#include <std_msgs/Int32.h>
#include <std_msgs/Float64.h>
#include <functional>
#include <ignition/math/Vector3.hh>

//* Header file for RBDL and Eigen
#include <rbdl/rbdl.h> // Rigid Body Dynamics Library (RBDL)
#include <rbdl/addons/urdfreader/urdfreader.h> // urdf model read using RBDL
#include <Eigen/Dense> // Eigen is a C++ template library for linear algebra: matrices, vectors, numerical solvers, and related algorithms.

//* Header file for
#include "CKubot.h"
#include "kinematics.h"

class CKubot C;
class Kinematics KM;

//#define PI      3.141592
#define D2R     PI/180.
#define R2D     180./PI

//Print color
#define C_BLACK   "\033[30m"
#define C_RED     "\x1b[91m"
#define C_GREEN   "\x1b[92m"
#define C_YELLOW  "\x1b[93m"
#define C_BLUE    "\x1b[94m"
#define C_MAGENTA "\x1b[95m"
#define C_CYAN    "\x1b[96m"
#define C_RESET   "\x1b[0m"

//Eigen//
using Eigen::MatrixXd;
using Eigen::VectorXd;


//RBDL//
using namespace RigidBodyDynamics;
using namespace RigidBodyDynamics::Math;

using namespace std;

// VectorXd q_init_R(6), q_cal_R(6), q0_R(6), q_R(6), q0_init_R(6), q0_final_R(6), q_prev_R(6);

double cnt = 0;
double cnt2 = 0;
double T = 1;

enum EndPointAxis {
    X = 0, Y, Z, Roll, Pitch, Yaw
};

typedef struct {
    VectorXd BA, LF, RF;
} GLOBAL;

GLOBAL Global;

typedef struct {
    VectorXd init;
    VectorXd cal;
    VectorXd fin;
    VectorXd pre;
} JOINT;

typedef struct {
    JOINT R;
    JOINT L;
} JointVariables;

JointVariables q;

#include <vector>
std::vector<std::vector<double>> save;

/*****************************************************************/

//Foot step Planner
//FootstepPlanner FootPlaner;


namespace gazebo
{

    class kubot_plugin : public ModelPlugin
    {
        //*** Variables for RoK-3 Simulation in Gazebo ***//
        //* TIME variable
        common::Time last_update_time;
        event::ConnectionPtr update_connection;
        double dt;
        double time = 0;

        //* Model & Link & Joint Typedefs
        physics::ModelPtr model;

        physics::JointPtr L_Hip_yaw_joint;
        physics::JointPtr L_Hip_roll_joint;
        physics::JointPtr L_Hip_pitch_joint;
        physics::JointPtr L_Knee_joint;
        physics::JointPtr L_Ankle_pitch_joint;
        physics::JointPtr L_Ankle_roll_joint;

        physics::JointPtr R_Hip_yaw_joint;
        physics::JointPtr R_Hip_roll_joint;
        physics::JointPtr R_Hip_pitch_joint;
        physics::JointPtr R_Knee_joint;
        physics::JointPtr R_Ankle_pitch_joint;
        physics::JointPtr R_Ankle_roll_joint;
        physics::JointPtr torso_joint;

        physics::JointPtr LS, RS;

        /* ROS */

        ros::NodeHandle nh;

        ros::Publisher RHY_pub;
        ros::Publisher LHY_pub;
        ros::Publisher LHR_pub;
        ros::Publisher LHP_pub;
        ros::Publisher LKN_pub;
        ros::Publisher LAP_pub;
        ros::Publisher LAR_pub;

        ros::Publisher test_pub;
        ros::Publisher test_pub2;
        ros::Publisher test_pub_L_z;
        ros::Publisher test_pub_R_z;

        ros::Publisher zmp_y_pub;
        ros::Publisher L_foot_z_pub;
        ros::Publisher R_foot_z_pub;
        ros::Publisher foot_x_pub;

        std_msgs::Float64 RHY_msg;
        std_msgs::Float64 LHY_msg;
        std_msgs::Float64 LHR_msg;
        std_msgs::Float64 LHP_msg;
        std_msgs::Float64 LKN_msg;
        std_msgs::Float64 LAP_msg;
        std_msgs::Float64 LAR_msg;

        std_msgs::Float64 test_msg;
        std_msgs::Float64 test_msg2;
        std_msgs::Float64 test_msg_L_z;
        std_msgs::Float64 test_msg_R_z;

        std_msgs::Float64 zmp_y_msg;
        std_msgs::Float64 L_foot_z_msg;
        std_msgs::Float64 R_foot_z_msg;
        std_msgs::Float64 foot_x_msg;

        //추가용
        ros::Publisher GLOBAL_LX_pub;
        ros::Publisher GLOBAL_RX_pub;
        ros::Publisher GLOBAL_LY_pub;
        ros::Publisher GLOBAL_RY_pub;

        std_msgs::Float64 GLOBAL_LX_msg;
        std_msgs::Float64 GLOBAL_RX_msg;
        //std_msgs::Float64 GLOBAL_LHP_msg;
        //std_msgs::Float64 GLOBAL_LKN_msg;
        //* Index setting for each joint
        
        enum
        {//wst 이건 뭐지
            WST = 0, LHY, LHR, LHP, LKN, LAP, LAR, RHY, RHR, RHP, RKN, RAP, RAR
        };

        //* Joint Variables
        int nDoF; // Total degrees of freedom, except position and orientation of the robot

        typedef struct RobotJoint //Joint variable struct for joint control 
        {
            double targetDegree; //The target deg, [deg]
            double targetRadian; //The target rad, [rad]

            double targetVelocity; //The target vel, [rad/s]
            double targetTorque; //The target torque, [N·m]

            double actualDegree; //The actual deg, [deg]
            double actualRadian; //The actual rad, [rad]
            double actualVelocity; //The actual vel, [rad/s]
            double actualRPM; //The actual rpm of input stage, [rpm]
            double actualTorque; //The actual torque, [N·m]

            double Kp;
            double Ki;
            double Kd;

        } ROBO_JOINT;
        ROBO_JOINT* joint;

    public:
        //*** Functions for RoK-3 Simulation in Gazebo ***//
        void Load(physics::ModelPtr _model, sdf::ElementPtr /*_sdf*/); // Loading model data and initializing the system before simulation 
        void UpdateAlgorithm(); // Algorithm update while simulation

        void jointController(); // Joint Controller for each joint

        void GetJoints(); // Get each joint data from [physics::ModelPtr _model]
        void GetjointData(); // Get encoder data of each joint

        void initializeJoint(); // Initialize joint variables for joint control
        void SetJointPIDgain(); // Set each joint PID gain for joint control
    };
    GZ_REGISTER_MODEL_PLUGIN(kubot_plugin);
}
void initializeKubot() {
    // Matrix3d C_des;
    // C_des = Matrix3d::Identity();
    // Eigen::Vector3d r_des;
    // Eigen::Vector3d r_des_R;
    // VectorXd q0(6);

    Global.BA = VectorXd::Zero(6);//BASE 6개짜리 벡터로 나타냄
    Global.LF = VectorXd::Zero(6);//왼다리 6개짜리 벡터로 나타냄
    Global.RF = VectorXd::Zero(6);//오른다리 6개짜리 벡터로 나타냄

    Global.BA(Z) = 0.308;// 0.308;
    Global.LF(Y) = 0.05;
    Global.RF(Y) = -0.05;

    q.L.init = VectorXd::Zero(6);
    q.R.init = VectorXd::Zero(6);

    // r_des << 0, 0.05, -0.33;
    // r_des_R << 0, -0.05, -0.33;
    // q0 << 0, 0, -30, 60, -30, 0;
    // q0 = q0*D2R;

    // q.L.cal = KM.inverseKinematics(r_des, C_des, q0, 0.001);
    // q.R.cal = KM.inverseKinematics_R(r_des_R, C_des, q0, 0.001);

    q.L.cal = KM.Geometric_IK_L(Global.BA, Global.LF);
    q.R.cal = KM.Geometric_IK_R(Global.BA, Global.RF);


    VectorXd GB_cfg(6), GF_cfg(6), ex_q(6);
    GB_cfg << 0, 0.1, 0.2, 0, 0, PI/4;
    GF_cfg << 0, 0.1, 0, 0, PI/3, 0;
    ex_q = KM.Geometric_IK_L(GB_cfg, GF_cfg);
    std::cout<<"ex_q = "<<ex_q<<std::endl;
        std::cout<<"jj"<<std::endl;
}


void gazebo::kubot_plugin::Load(physics::ModelPtr _model, sdf::ElementPtr /*_sdf*/)
{
    
    /*
     * Loading model data and initializing the system before simulation 
     */

    //* model.sdf file based model data input to [physics::ModelPtr model] for gazebo simulation
    model = _model;

    //* [physics::ModelPtr model] based model update
    GetJoints();



    //* RBDL API Version Check
    int version_test;
    version_test = rbdl_get_api_version();
    printf(C_GREEN "RBDL API version = %d\n" C_RESET, version_test);

    //* model.urdf file based model data input to [Model* rok3_model] for using RBDL
    Model* rok3_model = new Model();
    //Addons::URDFReadFromFile("/home/ola/.gazebo/models/rok3_model/urdf/rok3_model.urdf", rok3_model, true, true);
    Addons::URDFReadFromFile("/home/seokho/.gazebo/models/kubot22/urdf/kubot22.urdf", rok3_model, true, true);
    //↑↑↑ Check File Path ↑↑↑
    nDoF = rok3_model->dof_count - 6; // Get degrees of freedom, except position and orientation of the robot
    ROS_WARN("DOF : %d",nDoF);
    joint = new ROBO_JOINT[nDoF+1]; // Generation joint variables struct

    //* initialize and setting for robot control in gazebo simulation
    initializeJoint();
    SetJointPIDgain();


    //ROS Publishers
    LHY_pub = nh.advertise<std_msgs::Float64>("command_joint/LHY", 1000);//왼발 x좌표 ref값
    LHR_pub = nh.advertise<std_msgs::Float64>("command_joint/LHR", 1000);//왼발 y좌표 ref값
    LHP_pub = nh.advertise<std_msgs::Float64>("command_joint/LHP", 1000);
    LKN_pub = nh.advertise<std_msgs::Float64>("command_joint/LKN", 1000);
    LAP_pub = nh.advertise<std_msgs::Float64>("command_joint/LAP", 1000);
    LAR_pub = nh.advertise<std_msgs::Float64>("command_joint/LHR", 1000);

    RHY_pub = nh.advertise<std_msgs::Float64>("command_joint/RHY", 1000);//오른발 x좌표 ref값

    test_pub = nh.advertise<std_msgs::Float64>("kubotsim/test", 1000);
    test_pub2 = nh.advertise<std_msgs::Float64>("kubotsim/test2", 1000);
    test_pub_L_z = nh.advertise<std_msgs::Float64>("kubotsim/CoM_y", 1000);
    test_pub_R_z = nh.advertise<std_msgs::Float64>("kubotsim/zmp_y", 1000);

    zmp_y_pub = nh.advertise<std_msgs::Float64>("kubotsim/zmp_y_ref", 1000);
    L_foot_z_pub = nh.advertise<std_msgs::Float64>("kubotsim/L_foot_z", 1000);
    R_foot_z_pub = nh.advertise<std_msgs::Float64>("kubotsim/R_foot_z", 1000);

    //추가 확인용
    GLOBAL_LX_pub = nh.advertise<std_msgs::Float64>("LX", 1000);
    GLOBAL_RX_pub = nh.advertise<std_msgs::Float64>("RX", 1000);
    //GLOBAL_RHY_pub = nh.advertise<std_msgs::Float64>("command_joint/LAP", 1000);
    //GLOBAL_RAR_pub = nh.advertise<std_msgs::Float64>("command_joint/LHR", 1000);

    //* setting for getting dt
    
    //last_update_time = model->GetWorld()->GetSimTime();
    #if GAZEBO_MAJOR_VERSION >= 8
        last_update_time = model->GetWorld()->SimTime();
    #else
        last_update_time = model->GetWorld()->GetSimTime();
    #endif

    update_connection = event::Events::ConnectWorldUpdateBegin(boost::bind(&kubot_plugin::UpdateAlgorithm, this));
    //update_connection = event::Events::ConnectWorldUpdateBegin(boost::bind(&kubot_plugin::UpdateAlgorithm2, this));
    //update_connection = event::Events::ConnectWorldUpdateBegin(boost::bind(&kubot_plugin::UpdateAlgorithm3, this));
    
    initializeKubot();//여기선 glbal, 각도 값 초기화 해줌
        C.initializeCKubot();//로봇의 초기 발바닥 위치를 정해줌
        C.setWalkingStep(10, C.walking.step.S_R_F, 0, 0.05, 0, 0.05);
        C.setWalkingTime(0.4, 0.3);
        C.setZmpPreview(1.5);//여기서 프리뷰(몇 초 앞으로 내다볼지 정하고) gp를 계산함
        C.initializeZmpTraj();//프리뷰 관련 변수들 설정 여기서 + 
        C.FootPlanner();//foot planer에서 왼발 오른발 발자국 수만큼 행렬 만들어 주고 x,y좌표 계산함
        C.generateZmpTraj(C.walking.step.Lfoot, C.walking.step.Rfoot);//generateZmpTraj에서 foot planer에서 만든 행렬들을 x,y의 ref에다가 넣어준다
//C(cubot)라는 클래스 안에있는 함수들 호출함
}

void gazebo::kubot_plugin::UpdateAlgorithm()
{
    /*
     * Algorithm update while simulation
     */

    //* UPDATE TIME : 1ms
    ///common::Time current_time = model->GetWorld()->GetSimTime();
    #if GAZEBO_MAJOR_VERSION >= 8
        common::Time current_time = model->GetWorld()->SimTime();
    #else
        common::Time current_time = model->GetWorld()->GetSimTime();
    #endif

    dt = current_time.Double() - last_update_time.Double();
     //   cout << "dt:" << dt << endl;
    time = time + dt;


    //* setting for getting dt at next step
    last_update_time = current_time;

//    if((int)(time*1000)%5 == 0){
//       cout << "time:" << time << endl;

      //* Read Sensors data
      GetjointData();
//원래 로봇제어에선 4by4 행렬로 위치,로테이션 나타냈지만 위치3(x,y,z),로테이션3(roll,pitch,yaw)로 6개짜리 벡터로 넣어줘서 ik구함
//plugin_cc파일에선 1ms 기준인듯
      if (time <= C.zmp.previewControl.PreviewReadyTime) {//느낌이 global에는 위치벡터를 넣어주는 것 같고 q.l,pre에는 ik에서 구한 각도를 넣어주는 듯
              Global.BA(X) = C.zmp.previewControl.X.CoM;//BA는 크기 3개짜리 벡터 
              Global.BA(Y) = C.zmp.previewControl.Y.CoM;//여긴 딱 레디타임 로봇 초기 위치 조절
              Global.BA(Z) = C.cosWave(time, C.zmp.previewControl.PreviewReadyTime, 0.308, 0.25);

              q.L.pre = KM.Geometric_IK_L(Global.BA, Global.LF);//preview를 보면 com이 먼저 증가하기 때문에 ready time에도 com을 넣어줘야 함
              q.R.pre = KM.Geometric_IK_R(Global.BA, Global.RF);
          }//근데 이게 실시간으로 계산되는 건가 아님 다 계산된걸 넣어주는건가
          else if(time < C.zmp.previewControl.RefTotalTime - 2*C.zmp.previewControl.PreviewTime) {//딱 걷는 시간
              Global.BA(X) = C.zmp.previewControl.X.CoM;
              Global.BA(Y) = C.zmp.previewControl.Y.CoM;
              Global.BA(Z) = 0.25;
              if (C.walking.step.start_foot == C.walking.step.S_L_F){
                  Global.BA(Yaw) = C.LFoot.refpos(Yaw);
              }
              else if (C.walking.step.start_foot == C.walking.step.S_R_F){
                  Global.BA(Yaw) = C.RFoot.refpos(Yaw);
              }

              Global.LF(X) = C.LFoot.refpos(X);
              Global.LF(Y) = C.LFoot.refpos(Y);
              Global.LF(Z) = C.LFoot.refpos(Z);
              Global.LF(Yaw) = C.LFoot.refpos(Yaw);

              Global.RF(X) = C.RFoot.refpos(X);
              Global.RF(Y) = C.RFoot.refpos(Y);
              Global.RF(Z) = C.RFoot.refpos(Z);
              Global.RF(Yaw) = C.RFoot.refpos(Yaw);

              q.L.pre = KM.Geometric_IK_L(Global.BA, Global.LF);
              q.R.pre = KM.Geometric_IK_R(Global.BA, Global.RF);

              if (C.walking.time.sec >= C.walking.time.periodTime) {
                  C.walking.step.current++;
                  C.walking.time.sec = 0.0;
                  C.walking.step.LastLfoot = C.LFoot.refpos;
                  C.walking.step.LastRfoot = C.RFoot.refpos;
              }

              if(C.walking.time.sec >= C.walking.time.SSP_start_time and C.walking.time.sec <= C.walking.time.SSP_end_time) {//(s)기준 ssp시작시간부터 ssp
                  if((C.walking.step.current % 2) == 0) {
                      q.R.pre(1) = q.R.pre(1) - C.compensate(C.walking.time.sec - C.walking.time.SSP_start_time, C.walking.time.SSP_time, 0.8, 0, 1.38*D2R);
                  }
                  else if((C.walking.step.current % 2) == 1) {
                      q.L.pre(1) = q.L.pre(1) + C.compensate(C.walking.time.sec - C.walking.time.SSP_start_time, C.walking.time.SSP_time, 0.8, 0, 1.3*D2R);
                  }
              }
          }

          else {//프리뷰가 다 끝나고 프리뷰 타임*2만큼 남았을 때
              q.L.pre = KM.Geometric_IK_L(Global.BA, Global.LF);
              q.R.pre = KM.Geometric_IK_R(Global.BA, Global.RF);

          }

//          C.walking.time.sec = time - C.zmp.previewControl.PreviewReadyTime - C.walking.time.periodTime * C.walking.step.current ;
          C.generateFootTraj_ver2();//이게 다르네
//          C.zmp.previewControl.count = (int)(time*onesecSize);
          C.zmpPreviewControl();//preview controll계산내용

          //* Target Angles
          joint[LHY].targetRadian = q.L.pre(0);
          joint[LHR].targetRadian = q.L.pre(1);
          joint[LHP].targetRadian = q.L.pre(2);
          joint[LKN].targetRadian = q.L.pre(3);
          joint[LAP].targetRadian = q.L.pre(4);
          joint[LAR].targetRadian = q.L.pre(5);

          joint[RHY].targetRadian = q.R.pre(0);
          joint[RHR].targetRadian = q.R.pre(1);
          joint[RHP].targetRadian = q.R.pre(2);
          joint[RKN].targetRadian = q.R.pre(3);
          joint[RAP].targetRadian = q.R.pre(4);
          joint[RAR].targetRadian = q.R.pre(5);

          //* Publish topics
          LHY_msg.data = C.LFoot.refpos(X);
          LHR_msg.data = C.LFoot.refpos(Y);
          LHP_msg.data = C.LFoot.refpos(Z);
          RHY_msg.data = C.RFoot.refpos(X);
          LKN_msg.data = q.L.pre(3);
          LAP_msg.data = q.L.pre(4);
          LAR_msg.data = q.L.pre(5);
          LHY_pub.publish(LHY_msg);
          LHR_pub.publish(LHR_msg);
          LHP_pub.publish(LHP_msg);
          LKN_pub.publish(LKN_msg);
          LAP_pub.publish(LAP_msg);
          LAR_pub.publish(LAR_msg);
          RHY_pub.publish(RHY_msg);

          //추가 확인용!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
          GLOBAL_LX_msg.data = Global.LF(X);
          GLOBAL_RX_msg.data = Global.RF(X);
          //GLOBAL_LHP_msg.data = Global.LF(X);
          //GLOBAL_LHY_pub.publish(GLOBAL_LHY_msg);
          GLOBAL_LX_pub.publish(GLOBAL_LX_msg);
          GLOBAL_RX_pub.publish(GLOBAL_RX_msg);
          //* Joint Controller
          jointController();
//    }
    C.walking.time.sec = time - C.zmp.previewControl.PreviewReadyTime - C.walking.time.periodTime * C.walking.step.current ;
    C.zmp.previewControl.count = (int)(time*onesecSize);


}


void gazebo::kubot_plugin::jointController()
{
    /*
     * Joint Controller for each joint
     */

    // Update target torque by control
    for (int j = 0; j < nDoF+1; j++) {
        joint[j].targetTorque = joint[j].Kp * (joint[j].targetRadian-joint[j].actualRadian)\
                              + joint[j].Kd * (joint[j].targetVelocity-joint[j].actualVelocity);
    }

    // Update target torque in gazebo simulation     
   L_Hip_yaw_joint->SetForce(1, joint[LHY].targetTorque);
   L_Hip_roll_joint->SetForce(1, joint[LHR].targetTorque);
   L_Hip_pitch_joint->SetForce(1, joint[LHP].targetTorque);
   L_Knee_joint->SetForce(1, joint[LKN].targetTorque);
   L_Ankle_pitch_joint->SetForce(1, joint[LAP].targetTorque);
   L_Ankle_roll_joint->SetForce(1, joint[LAR].targetTorque);
   ///
   /// R_Hip_yaw_joint->SetForce(0, joint[RHY].targetTorque);
   /// R_Hip_roll_joint->SetForce(0, joint[RHR].targetTorque);
   /// R_Hip_pitch_joint->SetForce(0, joint[RHP].targetTorque);
   /// R_Knee_joint->SetForce(0, joint[RKN].targetTorque);
   /// R_Ankle_pitch_joint->SetForce(0, joint[RAP].targetTorque);
   /// R_Ankle_roll_joint->SetForce(0, joint[RAR].targetTorque);


    R_Hip_yaw_joint->SetForce(1, joint[RHY].targetTorque);
    R_Hip_roll_joint->SetForce(1, joint[RHR].targetTorque);
    R_Hip_pitch_joint->SetForce(1, joint[RHP].targetTorque);
    R_Knee_joint->SetForce(1, joint[RKN].targetTorque);
    R_Ankle_pitch_joint->SetForce(1, joint[RAP].targetTorque);
    R_Ankle_roll_joint->SetForce(1, joint[RAR].targetTorque);
    //torso_joint->SetForce(0, joint[WST].targetTorque);
    //ROS_WARN("torque: %lf",joint[RAR].targetTorque);
}

void gazebo::kubot_plugin::GetJoints()
{
    /*
     * Get each joints data from [physics::ModelPtr _model]
     */

    //* Joint specified in model.sdf
  /*
    L_Hip_yaw_joint = this->model->GetJoint("L_Hip_yaw_joint");
    L_Hip_roll_joint = this->model->GetJoint("L_Hip_roll_joint");
    L_Hip_pitch_joint = this->model->GetJoint("L_Hip_pitch_joint");
    L_Knee_joint = this->model->GetJoint("L_Knee_joint");
    L_Ankle_pitch_joint = this->model->GetJoint("L_Ankle_pitch_joint");
    L_Ankle_roll_joint = this->model->GetJoint("L_Ankle_roll_joint");
    R_Hip_yaw_joint = this->model->GetJoint("R_Hip_yaw_joint");
    R_Hip_roll_joint = this->model->GetJoint("R_Hip_roll_joint");
    R_Hip_pitch_joint = this->model->GetJoint("R_Hip_pitch_joint");
    R_Knee_joint = this->model->GetJoint("R_Knee_joint");
    R_Ankle_pitch_joint = this->model->GetJoint("R_Ankle_pitch_joint");
    R_Ankle_roll_joint = this->model->GetJoint("R_Ankle_roll_joint");
    torso_joint = this->model->GetJoint("torso_joint");
*/
    L_Hip_yaw_joint = this->model->GetJoint("LP");
    L_Hip_roll_joint = this->model->GetJoint("LPm");
    L_Hip_pitch_joint = this->model->GetJoint("LPd");
    L_Knee_joint = this->model->GetJoint("LK");
    L_Ankle_pitch_joint = this->model->GetJoint("LA");
    L_Ankle_roll_joint = this->model->GetJoint("LF");
    R_Hip_yaw_joint = this->model->GetJoint("RP");
    R_Hip_roll_joint = this->model->GetJoint("RPm");
    R_Hip_pitch_joint = this->model->GetJoint("RPd");
    R_Knee_joint = this->model->GetJoint("RK");
    R_Ankle_pitch_joint = this->model->GetJoint("RA");
    R_Ankle_roll_joint = this->model->GetJoint("RF");
    //* FTsensor joint
   // LS = this->model->GetJoint("LS");
    //RS = this->model->GetJoint("RS");
}

void gazebo::kubot_plugin::GetjointData()
{
    /*
     * Get encoder and velocity data of each joint
     * encoder unit : [rad] and unit conversion to [deg]
     * velocity unit : [rad/s] and unit conversion to [rpm]
     */
    
  #if GAZEBO_MAJOR_VERSION >= 8

    
    joint[LHY].actualRadian = L_Hip_yaw_joint->Position(0);
    joint[LHR].actualRadian = L_Hip_roll_joint->Position(0);
    joint[LHP].actualRadian = L_Hip_pitch_joint->Position(0);
    joint[LKN].actualRadian = L_Knee_joint->Position(0);
    joint[LAP].actualRadian = L_Ankle_pitch_joint->Position(0);
    joint[LAR].actualRadian = L_Ankle_roll_joint->Position(0);

    joint[RHY].actualRadian = R_Hip_yaw_joint->Position(0);
    joint[RHR].actualRadian = R_Hip_roll_joint->Position(0);
    joint[RHP].actualRadian = R_Hip_pitch_joint->Position(0);
    joint[RKN].actualRadian = R_Knee_joint->Position(0);
    joint[RAP].actualRadian = R_Ankle_pitch_joint->Position(0);
    joint[RAR].actualRadian = R_Ankle_roll_joint->Position(0);

    std::cout<<(joint[RKN].actualRadian)*R2D<<std::endl;

    //joint[WST].actualRadian = torso_joint->Position(0);

    
  #else
    joint[LHY].actualRadian = L_Hip_yaw_joint->GetAngle(0).Radian();
    joint[LHR].actualRadian = L_Hip_roll_joint->GetAngle(0).Radian();
    joint[LHP].actualRadian = L_Hip_pitch_joint->GetAngle(0).Radian();
    joint[LKN].actualRadian = L_Knee_joint->GetAngle(0).Radian();
    joint[LAP].actualRadian = L_Ankle_pitch_joint->GetAngle(0).Radian();
    joint[LAR].actualRadian = L_Ankle_roll_joint->GetAngle(0).Radian();

    joint[RHY].actualRadian = R_Hip_yaw_joint->GetAngle(0).Radian();
    joint[RHR].actualRadian = R_Hip_roll_joint->GetAngle(0).Radian();
    joint[RHP].actualRadian = R_Hip_pitch_joint->GetAngle(0).Radian();
    joint[RKN].actualRadian = R_Knee_joint->GetAngle(0).Radian();
    joint[RAP].actualRadian = R_Ankle_pitch_joint->GetAngle(0).Radian();
    joint[RAR].actualRadian = R_Ankle_roll_joint->GetAngle(0).Radian();

     ROS_WARN("ee");

    //joint[WST].actualRadian = torso_joint->GetAngle(0).Radian();
  #endif


    for (int j = 0; j < nDoF+1; j++) {
        joint[j].actualDegree = joint[j].actualRadian*R2D;
    }


    joint[LHY].actualVelocity = L_Hip_yaw_joint->GetVelocity(0);
    joint[LHR].actualVelocity = L_Hip_roll_joint->GetVelocity(0);
    joint[LHP].actualVelocity = L_Hip_pitch_joint->GetVelocity(0);
    joint[LKN].actualVelocity = L_Knee_joint->GetVelocity(0);
    joint[LAP].actualVelocity = L_Ankle_pitch_joint->GetVelocity(0);
    joint[LAR].actualVelocity = L_Ankle_roll_joint->GetVelocity(0);

    joint[RHY].actualVelocity = R_Hip_yaw_joint->GetVelocity(0);
    joint[RHR].actualVelocity = R_Hip_roll_joint->GetVelocity(0);
    joint[RHP].actualVelocity = R_Hip_pitch_joint->GetVelocity(0);
    joint[RKN].actualVelocity = R_Knee_joint->GetVelocity(0);
    joint[RAP].actualVelocity = R_Ankle_pitch_joint->GetVelocity(0);
    joint[RAR].actualVelocity = R_Ankle_roll_joint->GetVelocity(0);

    //joint[WST].actualVelocity = torso_joint->GetVelocity(0);


    //    for (int j = 0; j < nDoF; j++) {
    //        cout << "joint[" << j <<"]="<<joint[j].actualDegree<< endl;
    //    }

}

void gazebo::kubot_plugin::initializeJoint()
{
    /*
     * Initialize joint variables for joint control
     */
    
    for (int j = 0; j < nDoF+1; j++) {
        joint[j].targetDegree = 0;
        joint[j].targetRadian = 0;
        joint[j].targetVelocity = 0;
        joint[j].targetTorque = 0;
        
        joint[j].actualDegree = 0;
        joint[j].actualRadian = 0;
        joint[j].actualVelocity = 0;
        joint[j].actualRPM = 0;
        joint[j].actualTorque = 0;
    }
}

void gazebo::kubot_plugin::SetJointPIDgain()
{
    /*
     * Set each joint PID gain for joint control
     */
//    joint[LHY].Kp = 97.5;
//    joint[LHR].Kp = 202.5;
//    joint[LHP].Kp = 195.0;
//    joint[LKN].Kp = 127.5;
//    joint[LAP].Kp = 135.0;
//    joint[LAR].Kp = 127.5;
        joint[LHY].Kp = 120;
        joint[LHR].Kp = 120;
        joint[LHP].Kp = 120;
        joint[LKN].Kp = 120;
        joint[LAP].Kp = 120;
        joint[LAR].Kp = 120;

    joint[RHY].Kp = joint[LHY].Kp;
    joint[RHR].Kp = joint[LHR].Kp;
    joint[RHP].Kp = joint[LHP].Kp;
    joint[RKN].Kp = joint[LKN].Kp;
    joint[RAP].Kp = joint[LAP].Kp;
    joint[RAR].Kp = joint[LAR].Kp;

    //joint[WST].Kp = 2* 2.;
 
//    joint[LHY].Kd =   0.60;
//    joint[LHR].Kd =   1.35;
//    joint[LHP].Kd =   1.275;
//    joint[LKN].Kd =   0.75;
//    joint[LAP].Kd =   0.75;
//    joint[LAR].Kd =   0.375;

        joint[LHY].Kd =   0.45;
        joint[LHR].Kd =   0.45;
        joint[LHP].Kd =   0.45;
        joint[LKN].Kd =   0.45;
        joint[LAP].Kd =   0.45;
        joint[LAR].Kd =   0.45;

    joint[RHY].Kd = joint[LHY].Kd;
    joint[RHR].Kd = joint[LHR].Kd;
    joint[RHP].Kd = joint[LHP].Kd;
    joint[RKN].Kd = joint[LKN].Kd;
    joint[RAP].Kd = joint[LAP].Kd;
    joint[RAR].Kd = joint[LAR].Kd;

   // joint[WST].Kd = 2.;
}

