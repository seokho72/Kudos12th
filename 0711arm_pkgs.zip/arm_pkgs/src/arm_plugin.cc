#include <stdio.h>
#include <iostream>
#include <boost/bind.hpp>
#include <time.h>

//* Header file for Gazebo and Ros
#include <gazebo/gazebo.hh>
#include <ros/ros.h>

#include <gazebo/common/common.hh> 
#include <gazebo/common/Plugin.hh> //model plugin gazebo API에서 확인 
#include <gazebo/physics/physics.hh> //우리는 ODE physics 사용 
#include <gazebo/sensors/sensors.hh> //IMU sensor 사용 

#include <std_msgs/Float32MultiArray.h>
#include <std_msgs/Int32.h>
#include <std_msgs/Float64.h>
#include <std_msgs/Float64MultiArray.h> //topic을 어떤 형태로 보내는지에 따라 사용되는 헤더파일이다.

#include <functional>
#include <ignition/math/Vector3.hh>

#define PI      3.141592
#define D2R     PI/180.
#define R2D     180./PI 

//* Print color
#define C_BLACK   "\033[30m"
#define C_RED     "\x1b[91m"
#define C_GREEN   "\x1b[92m"
#define C_YELLOW  "\x1b[93m"
#define C_BLUE    "\x1b[94m"
#define C_MAGENTA "\x1b[95m"
#define C_CYAN    "\x1b[96m"
#define C_RESET   "\x1b[0m"

using namespace std;
//여기까지가 책으로 따지자면 목차이다. namespace까지

namespace gazebo {

    class arm_plugin : public ModelPlugin
    {
        //*** Variables for Kubot Simulation in Gazebo ***//
        //* TIME variable
        common::Time last_update_time;
        event::ConnectionPtr update_connection;
        double dt;
        double time = 0;

        physics::ModelPtr model; // model = _model 관련

        physics::JointPtr Link1_joint;
        physics::JointPtr Link2_joint;

        enum
        { 
            LK1 = 0, LK2
        };

        //* Joint Variables
        int nDoF; // Total degrees of freedom, except position and orientation of the robot
//구조체는 변수 집합이라고 생각하면 편하다.
        typedef struct RobotJoint //Joint variable struct for joint control 
        {
            double targetDegree; //The target deg, [deg]
            double targetRadian; //The target rad, [rad]
            double init_targetradian;

            double targetRadian_interpolation; //The interpolated target rad, [rad]

            double targetVelocity; //The target vel, [rad/s]
            double targetTorque; //The target torque, [N·m]

            double actualDegree; //The actual deg, [deg]
            double actualRadian; //The actual rad, [rad]
            double actualVelocity; //The actual vel, [rad/s]
            double actualRPM; //The actual rpm of input stage, [rpm]
            double actualTorque; //The actual torque, [N·m]

            double Kp;
            double Ki;
            double Kd;
        } ROBO_JOINT;
        ROBO_JOINT* joint;                


    public :
            //*** Functions for Kubot Simulation in Gazebo ***//
          void Load(physics::ModelPtr _model, sdf::ElementPtr /*_sdf*/); // Loading model data and initializing the system before simulation 
          void UpdateAlgorithm(); // Algorithm update while simulation
          
          void setjoints(); // Get each joint data from [physics::ModelPtr _model]    
          void getjointdata(); // Get encoder data of each joint

          void jointcontroller();
          
          void initializejoint(); 
          void setjointPIDgain(); 
    };
    GZ_REGISTER_MODEL_PLUGIN(arm_plugin);
    
}

void gazebo::arm_plugin::Load(physics::ModelPtr _model, sdf::ElementPtr /*_sdf*/)
{
    //* model.sdf file based model data input to [physics::ModelPtr model] for gazebo simulation
    model = _model;

    setjoints();
    //sdf변환하기 전에 urdf파일에서 조인트가 몇개인지 인식을 함.
    //인식이 끝나면 joint 갯수에 맞게 구조체를 여러개 생성
    //Robotjoint 구조체를 joint 갯수만큼 복제되는 거임

    nDoF = 2; // Get degrees of freedom, except position and orientation of the robot
  
    joint = new ROBO_JOINT[nDoF]; // Generation joint variables struct    
    
    initializejoint();
    setjointPIDgain();
    //* setting for getting dt
    last_update_time = model->GetWorld()->SimTime();
    update_connection = event::Events::ConnectWorldUpdateBegin(boost::bind(&arm_plugin::UpdateAlgorithm, this));
    
}

void gazebo::arm_plugin::UpdateAlgorithm()
{
    //* UPDATE TIME : 1ms
    common::Time current_time = model->GetWorld()->SimTime();
    dt = current_time.Double() - last_update_time.Double();
    //        cout << "dt:" << dt << endl;
    time = time + dt;
    //    cout << "time:" << time << endl;

    //* setting for getting dt at next step
    last_update_time = current_time;
    
    getjointdata();
    // printf(C_BLUE "time = %f\n" C_RESET, time);

    jointcontroller();        
}

void gazebo::arm_plugin::setjoints() //plugin에다가 joints name 설정 .sdf파일에서 설정한 이름이랑 확인하기
{
    /*
     * Get each joints data from [physics::ModelPtr _model]
     */

    //* Joint specified in model.sdf
    Link1_joint = this->model->GetJoint("Link1_joint");
    Link2_joint = this->model->GetJoint("Link2_joint");
}

void gazebo::arm_plugin::getjointdata()
{
    /*
     * Get encoder and velocity data of each joint[j].targetRadian = joint_h[j];
     * encoder unit : [rad] and unit conversion to [deg]
     * velocity unit : [rad/s] and unit conversion to [rpm]
     */
    joint[LK1].actualRadian = Link1_joint->Position(0);
    joint[LK2].actualRadian = Link2_joint->Position(0);


    for (int j = 0; j < nDoF; j++) {
        joint[j].actualDegree = joint[j].actualRadian*R2D;
        printf(C_BLUE "joint[%d].actualDegree = %f\n" C_RESET, j, joint[j].actualDegree);
    }

    joint[LK1].actualVelocity = Link1_joint->GetVelocity(0);
    joint[LK2].actualVelocity = Link2_joint->GetVelocity(0);


    for (int j = 0; j < nDoF; j++) {

        printf(C_BLUE "joint[%d].targetVelocity = %f\n" C_RESET, j, joint[j].targetVelocity);
    }

    joint[LK1].actualTorque = Link1_joint->GetForce(0);
    joint[LK2].actualTorque = Link2_joint->GetForce(0);
    

    for (int j = 0; j < nDoF; j++) {

        joint[j].actualRPM = joint[j].actualVelocity * 60. / (2 * PI);
    }

}

void gazebo::arm_plugin::jointcontroller()
{
        static double pre_rad[2];

        for (int j = 0; j < nDoF; j++){

            joint[j].targetRadian = joint[j].init_targetradian;
            joint[j].targetDegree = joint[j].targetRadian*R2D;

            joint[j].targetVelocity = (joint[j].targetRadian - pre_rad[j]) / dt;
            pre_rad[j] = joint[j].targetRadian;                

            joint[j].targetTorque = joint[j].Kp*(joint[j].targetRadian-joint[j].actualRadian) \
                                  + joint[j].Kd*(joint[j].targetVelocity -joint[j].actualVelocity);

        }
          

        //* Update target torque in gazebo simulation
        Link1_joint->SetForce(0, joint[LK1].targetTorque);
        Link2_joint->SetForce(0, joint[LK2].targetTorque);

        
}

void gazebo::arm_plugin::initializejoint()
{
    /*
     * Initialize joint variables for joint control
     */
        joint[0].init_targetradian= 45*D2R; // Link1_joint
        joint[1].init_targetradian= 90*D2R; // Link2_joint

}

void gazebo::arm_plugin::setjointPIDgain()
{
    /*
     * Set each joint PID gain for joint control
     */
        joint[LK1].Kp = 1;
        joint[LK2].Kp = 1;

        joint[LK1].Kd = 0.01;
        joint[LK2].Kd = 0.01;

}